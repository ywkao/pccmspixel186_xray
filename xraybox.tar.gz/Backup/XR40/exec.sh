#!/bin/bash
./xraybox.py tasks_timing
./xraybox.py tasks_timing
./xraybox.py tasks_timing_an
./xraybox.py tasks_timing_an

#!/usr/bin/env python

import xraybox

xr40 = xraybox.Xraybox(iPort="/dev/ttyUSB0",commtime=0.1)

#print xr40.getHWversion()
#print xr40.getFWversion()
#print xr40.getDoor()
#print xr40.getTime()
#print xr40.getDate()

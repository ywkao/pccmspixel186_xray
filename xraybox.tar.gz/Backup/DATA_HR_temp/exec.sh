#! /usr/bin/env bash

for num in 01 02 04 05 08 09 10 11 13 14 15 17 19 21 22 24 25 28 30 32 33 34 35 36 38 39 40 42 43 44 46 49 55 56 58 59
do
    ./getDat.sh M30${num}
done
